$(document).ready(function(){   

    $("#category").change(function()
    {  
    	var category = $('#category').find(":selected").text(); 
		$.ajax({
         type: "POST",
         url: BASE_URL + "index.php/ajax/update", 
         data: { category : category },  
         cache:false,
         dataType: "json",
         success: 
              function(data){

                $("#intent").html(data.intent);
                $("#content_utterance").html(data.content_utterance);
                $("#content_identifier").html(data.content_identifier);
                $("#answer_block").html(data.answer_block);
                $("#reviewer_identifier").val(data.answer_identifier);
                /*
                
                
                
                */
              }
		});
 
	});
	
	$("#intent").change(function()
    {  
    	var intent = $('#intent').find(":selected").text(); 
	     $.ajax({
	         type: "POST",
	         url: BASE_URL + "index.php/ajax/intent", 
	         data: { intent: intent },
	         dataType: "json",  
	         cache:false,
	         success: 
	              function(data){
	                
	                $("#content_utterance").html(data.content_utterance);
	                $("#content_identifier").html(data.content_identifier);
	                $("#answer_block").html(data.answer_block);
					$("#reviewer_identifier").val(data.answer_identifier);
	                
	              }

		 });
 
	});
	
});