<?php
class Content_model extends CI_Model {


        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
        }

        public function get_categories()
        {
	        
	        $query = $this->db->query("SELECT DISTINCT(category) from intent");
	        return $query->result();
        }
        
        public function get_first_answer($category)
        {
	        $query = $this->db->query("SELECT answer_identifier from intent where category = ?", array($category)); 
	        $result = $query->row();
	        return $result->answer_identifier;
        }
        
        public function get_intents($category)
        {
	     	$query = $this->db->query("SELECT DISTINCT(intent) from intent where category = ?", array($category));  
	     	return $query->result();
 
        }
        
        public function get_intents_html($category) {
	        
	       $query = $this->db->query("SELECT DISTINCT(intent) from intent where category = ?", array($category));  
	       $html = "";

	       foreach ($query->result() as $row) {
	 
				  $html .= "<option name='{$row->intent}'>{$row->intent}</option>";
		   }
		       
	       return $html;
	        
        }
        
        public function get_answer_identifier($intent)
        {
	        
	        $query = $this->db->query("SELECT answer_identifier from intent where intent = ?", array($intent));
	        $result = $query->row();
	        return $result->answer_identifier;
        }
        
        
        public function get_content($answer_identifier)
        {
            $query = $this->db->query("SELECT * from intent where answer_identifier = ?", array($answer_identifier));
            return $query->row();
        }
        
        public function get_content_html($answer_identifier)
        {
	        
	        $query = $this->db->query("SELECT * from intent where answer_identifier = ?", array($answer_identifier));
	        $content = $query->row();
	        ob_start();
	        ?>
	       <div class="col-xs-3">
				<label>Last Edit Date:</label>
				<?php echo $content->date; ?>
			</div>
			
			<div class="col-xs-3">
				<label>Identifier:</label>
				<?php echo $content->answer_identifier; ?>
			</div>

			<?php
			$answer["identifier"] = ob_get_clean();
			
			ob_start();
			?>
			
			<label>Utterance(s):</label>
			<textarea readonly="true" class="form-control" rows="18"><?php echo trim($content->utterance); ?></textarea>
			
			<?php
			$answer["utterance"] = ob_get_clean();
	        
	        return $answer;
        }
        
        
        public function get_answer($answer_identifier)
        {
	         $query = $this->db->query("SELECT * from answer where identifier LIKE '$answer_identifier%'");
             return $query->result();

        }
        
        public function get_answer_html($answer_identifier)
        {
	        
	        $query = $this->db->query("SELECT * from answer where identifier LIKE '$answer_identifier%'");
	        ob_start();
	        foreach ($query->result() as $r) :
	        ?>
	        <div class="row">
			<div class="col-xs-4">
			<label>Identifier:</label>
			 <?php echo $r->identifier; ?>
			 <br/>
			 <label>Description:</label>
			 <?php echo $r->description; ?>
			</div>
			<div class="col-xs-8">
				<div class="row">
					<div class="col-xs-12">
						<label>Answer verbal and text:</label>
						<textarea readonly="true" class="form-control" rows="3"><?php echo $r->voice_answer; ?></textarea>
					</div>
					<div class="col-xs-12">
						
						<label>Answer text only:</label>
						<textarea readonly="true" class="form-control" rows="3"><?php echo $r->text_answer; ?></textarea>
					</div>
				</div>
			</div>	
			
		</div>
		<hr/>

			<?php endforeach;
	        $html = ob_get_clean();
	        return $html;
        }

}
?>