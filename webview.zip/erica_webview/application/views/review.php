<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Erica Webview</title>

	<link rel="stylesheet" href="_core/css/bootstrap.min.css?v=1">
	<link rel="stylesheet" href="_core/css/bootstrap-theme.min.css?v=1">
	<link rel="stylesheet" href="_core/css/main.css">
	<script type="text/javascript">
    var BASE_URL = "<?php echo base_url();?>erica_webview/";
	</script>

</head>
<body>
<div class="container" id="webview">
	<div class="row">

		<div class="col-xs-3">
			<label>Category:</label> 
			<select class="form-control" id="category" name="category">
				<?php foreach ($categories as $r) : ?>
				<option name="<?php echo $r->category; ?>"><?php echo $r->category; ?></option>
				<?php endforeach; ?>
			</select>

		</div>
		
		<div class="col-xs-3">
			<label>Intent:</label>
			<select class="form-control" name="intent" id="intent">
				<?php foreach ($intents as $r) : ?>
				<option name="<?php echo $r->intent; ?>"><?php echo $r->intent; ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div id="content_identifier">
		<div class="col-xs-3">
			<label>Last Edit Date:</label>
			<?php echo $content->date; ?>
		</div>
		
		<div class="col-xs-3">
			<label>Identifier:</label>
			<?php echo $content->answer_identifier; ?>
		</div>
		
		</div>
	</div>
	<hr/>
	<div class="row">
		<?php /*
		<div class="col-xs-6">
			<label>Main Doc Correlation:</label> 
			<textarea readonly="true" class="form-control" rows="3"><?php echo $content->{'main doc correlation'}; ?></textarea>
		</div>
		*/ ?>
		<div class="col-xs-4" id="content_utterance">
			<label>Utterance(s):</label>
			<textarea readonly="true" class="form-control" rows="18"><?php echo trim($content->utterance); ?></textarea>
		</div>
		<div class="col-xs-8">
			<label>Answers(s):</label>
			<div id="answer_block">
	<?php foreach ($answer as $r) : ?>
	<div class="row">
		<div class="col-xs-4">
			<label>Identifier:</label>
			 <?php echo $r->identifier; ?>
			 <br/>
			 <label>Description:</label>
			 <?php echo $r->description; ?>
		</div>
		<div class="col-xs-8">
			<div class="row">
				<div class="col-xs-12">
					<label>Answer verbal and text:</label>
					<textarea readonly="true" class="form-control" rows="3"><?php echo $r->voice_answer; ?></textarea>
				</div>
				<div class="col-xs-12">
					
					<label>Answer text only:</label>
					<textarea readonly="true" class="form-control" rows="3"><?php echo $r->text_answer; ?></textarea>
				</div>
			</div>
		</div>	
		
	</div>
	<hr/>
	<?php endforeach; ?>
			</div>
	</div>

		
	</div>
	

	<hr/>
	<div class="row">
		<div class="col-xs-2">
				<button class="btn btn-default btn-block intent">&laquo; Previous Intent</button>

		</div>
		<div class="col-xs-2">
			<button class="btn btn-default btn-block intent" value="Next Intent" />Next Intent &raquo;</button>
		</div>
		<div class="col-xs-8">
			<form id="reviewer_form">
	
			<input type="hidden" name="reviewer_identifier" id="reviewer_identifier" value= "<?php echo $answer_identifier; ?>" />
			<label>Reviewer Notes:</label>
			<textarea id="review_notes" name="review_notes" class="form-control review" rows="4" ></textarea>
			<input type="button" class="btn btn-primary right" id="save_notes" value="Save Reviewer Notes" />
			</form>
		</div>
		
	</div>
		
	
</div> <!-- webview -->
	 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="_core/js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="_core/js/bootstrap.min.js"></script>
    <script src="_core/js/main.js"></script>
</body>
</html>