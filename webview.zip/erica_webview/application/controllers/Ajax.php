<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

  public function update()
  {
    
    	$category = trim($_POST['category']);
		// if the username exists return a 1 indicating true
    	$intent_html = $this->content_model->get_intents_html($category);
		
		$answer_identifier = $this->content_model->get_first_answer($category);
		
		
		$utterance = $this->content_model->get_content_html($answer_identifier);
		
		$response["content_utterance"] = $utterance["utterance"];
		$response["content_identifier"] = $utterance["identifier"];
		
		$response["answer_block"] = $this->content_model->get_answer_html($answer_identifier);
		$response["answer_identifier"] = $answer_identifier;
		$response["intent"] = $intent_html;
    	echo json_encode($response);
   }
 
 
   public function intent()
   {
		$intent = trim($_POST['intent']);
		
		$answer_identifier = $this->content_model->get_answer_identifier($intent);
		
		$utterance = $this->content_model->get_content_html($answer_identifier);
		
		$response["content_utterance"] = $utterance["utterance"];
		$response["content_identifier"] = $utterance["identifier"];
		
		$response["answer_block"] = $this->content_model->get_answer_html($answer_identifier);
		
		$response["answer_identifier"] = $answer_identifier;

		
		echo json_encode($response);

	   
  }
}