<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 	 
	public function index()
	{
		$category = "Balance";
		$answer_identifier = "EBA0001";

		/* load all categories */
		$data['categories'] = $this->content_model->get_categories();
		
		/* if set, get current category */
		
		/* if category set, load all intents */
		$data['intents'] = $this->content_model->get_intents($category);
		
		/* if intent set, load all content */
		
		
		/* defaults if none set */
		
		$data['content'] = $this->content_model->get_content($answer_identifier);
		
		$data['answer'] = $this->content_model->get_answer($answer_identifier);
		
		$data['answer_identifier'] = $answer_identifier;
		
		$this->load->view('review', $data);
	}
	
	
}
